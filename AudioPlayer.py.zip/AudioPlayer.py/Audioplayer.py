import flet as ft
import flet_audio as fta

songs = [
    "songs/happier.mp3",  
    "songs/mine.mp3",
    "songs/olivia.mp3",
    "songs/rude.mp3",
    "songs/treat.mp3",
]
covers = [
    "covers/olivia.jpg",  
    "covers/mine2.jpg",
    "covers/olivia2.jpg",
    "covers/rude2.jpg",
    "covers/better2.jpg",
]

current_song_index = 0

def main(page: ft.Page):
    page.bgcolor = "#FFFCE4EC"
    global current_song_index

    async def playAudio(e):
        await audio1.play()

    async def pauseAudio(e):
        await audio1.pause()

    async def resumeAudio(e):
        await audio1.resume()

    async def getAudioDuration(e):
        duration = await audio1.get_duration()
        durationText.value = f"Song duration: {duration}"
        page.update()

    async def getSongPosition(e):
        position = await audio1.get_current_position()
        positionText.value = f"Current position: {position}"
        page.update()

    async def next_song(e):
        global current_song_index
        current_song_index = (current_song_index + 1) % len(songs)
        audio1.src = songs[current_song_index]
        cover.src = covers[current_song_index]
        page.update()
        await audio1.play()

    async def previous_song(e):
        global current_song_index
        current_song_index = (current_song_index - 1) % len(songs)
        audio1.src = songs[current_song_index]
        cover.src = covers[current_song_index]
        page.update()
        await audio1.play()

    def changeVolume(e):
        audio1.volume = volumeSlider.value / 100
        audio1.update()

    audio1 = fta.Audio(src=songs[current_song_index])
    page.services.append(audio1)
    page.update()

    cover = ft.Image(src=covers[current_song_index], width=200, height=200)

    playButton = ft.Button("Play", on_click=playAudio)
    pauseButton = ft.Button("Pause", on_click=pauseAudio)
    resumeButton = ft.Button("Resume", on_click=resumeAudio)
    getDurationButton = ft.Button("Get Duration", on_click=getAudioDuration)
    getPositionButton = ft.Button("Get current position", on_click=getSongPosition)

    volumeSlider = ft.Slider(value=100, divisions=100, max=100, min=0, on_change=changeVolume)

    durationText = ft.Text(value="Song duration: ")
    positionText = ft.Text(value="Current position: ")

    controls = ft.Row(
        [
            ft.IconButton(icon=ft.Icons.SKIP_PREVIOUS, on_click=previous_song),
            playButton,
            pauseButton,
            resumeButton,
            ft.IconButton(icon=ft.Icons.SKIP_NEXT, on_click=next_song),
        ],
        alignment=ft.MainAxisAlignment.CENTER,
    )

    page.add(
    ft.Row([cover], alignment=ft.MainAxisAlignment.CENTER),
    controls,
    ft.Row([getDurationButton, getPositionButton], alignment=ft.MainAxisAlignment.CENTER),  # ← both in one row
    volumeSlider,
    durationText,
    positionText,
)
ft.run(main=main, assets_dir="assets")